"""One GoToPose authority: NMPC tracking, zero-command settling, typed result.

The solver worker owns its warm start. The ROS thread owns input callbacks,
request identity, the 50 Hz command heartbeat and all safety/result decisions.
"""
import json
import math
import time
import numpy as np
from concurrent.futures import ThreadPoolExecutor

from geometry_msgs.msg import PoseStamped, Twist
from nav_msgs.msg import Path
from pinky_soccer_dynamics import params as dyn_params
from pinky_soccer_dynamics.command_adapter import CommandAdapter, wheels_from_joint_state
from pinky_soccer_dynamics.profile_model import motor_step
from pinky_soccer_msgs.msg import BehaviorGoal, WorldModel, MotionResult
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
import rclpy
from sensor_msgs.msg import JointState
from std_msgs.msg import String

from .arrival import Arrival, wrap
from .pose_mpc import PoseMpc
from .time_optimal import TimeOptimalMpc
from .acados_time_optimal import AcadosTimeOptimalMpc
from .scheduled_input import ScheduledInput
from .delay_observer import DelayObserver,FORECAST_TAU
from . import collision_geometry
from . import obstacle_snapshot
from .response_calibration import apply_response
from .timing_trace import TimingTrace


class MpcController(Node):
    def __init__(self):
        super().__init__('mpc_controller')
        p=self.declare_parameter
        target=p('target','real').value
        profile=p('calibration_profile','').value
        identification=p('identification','').value
        self.params=dyn_params.load(target,profile=profile or None)
        self.params,self.response_calibration=apply_response(self.params,identification)
        if self.params.m('delay') > 0.:
            raise ValueError('Phase-1 predictor does not compensate transport delay')
        self.max_lin=float(p('max_lin',0.).value)
        self.max_ang=float(p('max_ang',0.).value)
        self.goal_timeout=float(p('goal_timeout',.5).value)
        self.pose_timeout=float(p('pose_timeout',.5).value)
        self.rate=float(p('rate_hz',10.).value)
        self.command_rate=float(p('command_rate_hz',50.).value)
        self.dt=1/self.rate
        self.mpc=PoseMpc(self.params,p('horizon',2.).value,int(p('steps',20).value))
        if abs(self.dt-self.mpc.dt)>1e-6:
            raise ValueError('horizon/steps must match optimization period')
        self.time_backend=p('mpc_backend','acados').value
        if self.time_backend not in ('acados','slsqp'):
            raise ValueError('mpc_backend must be acados or slsqp')
        solver_cls=AcadosTimeOptimalMpc if self.time_backend=='acados' else TimeOptimalMpc
        damping_scale=float(p('mpc_damping_scale',0.).value)
        self.observer_mode=p('mpc_observer_mode','off').value
        if self.observer_mode not in ('off','align','ndob'):
            raise ValueError('mpc_observer_mode must be off, align or ndob')
        if self.observer_mode!='off' and self.time_backend!='acados':
            raise ValueError('delay observer requires acados')
        self.observer=DelayObserver(self.params,enabled=self.observer_mode=='ndob')
        self.pose_source_sim=None
        self.wheel_source_sim=None
        self.wheel_stamp_valid=False
        self.aligned_pose=None
        self.aligned_wheels=None
        self.observer_disturbance=np.zeros(2)
        kwargs={'damping_scale':damping_scale} if self.time_backend=='acados' else {}
        self.time_mpc=solver_cls(self.params, dt=self.dt,
             max_steps=int(p('time_optimal_max_steps',80).value),
             budget=float(p('time_optimal_budget_sec',.075).value),**kwargs)
        self.schedule=ScheduledInput(self.dt, min(.025,.45*self.dt))
        self.future_scheduled=False
        self.future_predicted=None
        self.active_predicted=None
        self.active_solve_id=None
        self.pose_receipt_sim=None
        self.adapter=CommandAdapter(self.params)
        self.arrival=Arrival(float(p('pos_tol',.02).value),
                             float(p('ang_tol',math.radians(3)).value),
                             float(p('settle_sec',.3).value))
        self.wheel_feedback=bool(p('wheel_feedback',False).value)
        # Optional GoToPose collision constraints (BehaviorGoal avoid_*). With all options
        # off the request uses self.time_mpc exactly as before; the extended solver is
        # generated/loaded here, outside the control loop.
        self.avoid_config=obstacle_snapshot.AvoidanceConfig(
            margin=float(p('avoid_margin',.02).value),
            solver_margin=float(p('avoid_solver_margin',.005).value),
            opponent_radius=float(p('avoid_opponent_radius',.10).value),
            ball_radius=float(p('avoid_ball_radius',.02135).value))
        self.avoid_mpc=None
        self.avoid_field=None
        if self.time_backend=='acados' and bool(p('avoidance_solver',True).value):
            from pinky_soccer_field.field_geometry import Field
            from .avoidance_mpc import AvoidanceTimeOptimalMpc
            spec=p('field_spec','').value
            self.avoid_field=collision_geometry.FieldObstacles(Field.from_file(spec or None))
            self.avoid_mpc=AvoidanceTimeOptimalMpc(self.params, dt=self.dt,
                 max_steps=self.time_mpc.max_steps,budget=self.time_mpc.budget,**kwargs)
        self.world_msg=None
        self.avoid_worker_key=None
        # GoToPose INITIALIZING: until the first optimized command is applied, missed
        # activation slots are not consecutive tracking failures (the robot holds zero
        # command) and the worker keeps the same goal_id's warm start; after init_timeout_sec
        # (node clock) without a first command the request fails. TRACKING is unchanged.
        self.init_timeout=float(p('init_timeout_sec',1.).value)
        if not (math.isfinite(self.init_timeout) and self.init_timeout>0):
            raise ValueError('init_timeout_sec must be positive')
        self.tracking=False
        self.init_start=None
        self.init_missed=0
        self.worker_key=None
        self.avoid=obstacle_snapshot.AvoidanceOptions()
        self.forward_only=set(p('forward_only_actions',[
            'GoBehindBall','PushBall','GoToBlockPoint','FaceBall','TurnToLastSeen']).value)
        self.goal=self.pose=self.measured=None
        self.goal_time=self.pose_time=self.measured_time=None
        self.pose_valid=False
        self.world_v=0.
        self.omega=self.ref=self.last_cmd=(0.,0.)
        self.last_tick=None
        self.key=None
        self.generation=0
        self.worker_generation=None
        self.future=None
        self.future_generation=None
        self.future_wall=None
        self.future_sim=None
        self.solve_id=0
        self.last_solution_input_sim=None
        self.last_solution_input_wall=None
        self.next_solve=0.
        self.last_solution=None
        self.last_solution_sim=None
        self.last_solution_wall=None
        self.failures=0
        self.failed_reason=None
        self.feedback_age=None
        self.diag={}
        self.timing_trace=TimingTrace()
        p('timing_trace',False)  # Optional JSON diagnostics, dynamically enabled by test recorder.
        self.future_goal_id=None
        self.future_due=None
        self.progress_time=None
        self.progress_best=None
        self.executor_pool=ThreadPoolExecutor(max_workers=1)
        self.pub=self.create_publisher(Twist,'cmd_vel',10)
        self.path_pub=self.create_publisher(Path,'mpc/predicted_path',10)
        self.status_pub=self.create_publisher(String,'mpc/status',10)
        self.result_pub=self.create_publisher(MotionResult,'motion/result',10)
        self.create_subscription(BehaviorGoal,'behavior_goal',self.on_goal,10)
        self.create_subscription(WorldModel,'world_model',self.on_world,10)
        self.obstacle_world = None
        self.obstacle_world_received = None
        self.create_subscription(WorldModel,'world_model/obstacles',self.on_obstacle_world,10)
        if self.wheel_feedback:
            self.create_subscription(JointState,'joint_states',self.on_joints,qos_profile_sensor_data)
        self.create_timer(1/self.command_rate,self.tick)
        self.get_logger().info(f'Fixed-step time-optimal NMPC {target}/{self.time_backend}: {self.rate:g} Hz solve, '
                               f'{self.command_rate:g} Hz command; up to {self.time_mpc.max_steps} stages; '
                               f'{self.mpc.wmax*30/math.pi:.1f} RPM')
        if self.response_calibration['applied']:
            self.get_logger().info('Real motor response: '+json.dumps(self.response_calibration))

    def on_goal(self,msg):
        self.goal,self.goal_time=msg,time.monotonic()

    def on_obstacle_world(self,msg):
        """Unconfirmed scan obstacles: independent of the displayed single opponent."""
        self.obstacle_world = msg
        self.obstacle_world_received = time.monotonic()

    def avoidance_world(self):
        """Legacy producers remain compatible; use fresh candidate stream when present."""
        if (getattr(self, 'obstacle_world', None) is not None
                and self.obstacle_world_received is not None
                and time.monotonic()-self.obstacle_world_received <= .5):
            return self.obstacle_world
        return self.world_msg

    def on_world(self,msg):
        self.world_msg=msg
        s=msg.self
        self.pose=(s.pose.x,s.pose.y,s.pose.theta)
        self.pose_time=time.monotonic()
        self.pose_receipt_sim=self.get_clock().now().nanoseconds*1e-9
        stamp=s.last_seen.sec+s.last_seen.nanosec*1e-9
        self.pose_source_sim=stamp if stamp>0 else None
        self.world_v=math.hypot(s.velocity.x,s.velocity.y)
        self.pose_valid=(s.state!=s.LOST and s.confidence>0 and
                         all(math.isfinite(v) for v in (*self.pose,self.world_v)))

    def on_joints(self,msg):
        try:
            wheel=wheels_from_joint_state(self.params,msg.name,msg.velocity)
            if all(math.isfinite(v) for v in wheel):
                if self.observer_mode!='off':
                    receipt=self.get_clock().now().nanoseconds*1e-9
                    source=msg.header.stamp.sec+msg.header.stamp.nanosec*1e-9
                    stamp=source if source>0 else receipt
                    if not self.observer.measure(stamp,receipt,wheel):
                        return
                    self.wheel_stamp_valid=source>0
                    self.wheel_source_sim=min(stamp,receipt)
                self.measured,self.measured_time=wheel,time.monotonic()
        except (KeyError,ValueError,IndexError):
            pass

    def caps(self):
        v,w=self.max_lin,self.max_ang
        if self.goal.max_speed>0:
            if self.goal.action=='SpinInPlace':
                w=min(w,self.goal.max_speed) if w else self.goal.max_speed
            else:
                v=min(v,self.goal.max_speed) if v else self.goal.max_speed
        return v,w

    def send(self,u):
        self.last_cmd=tuple(float(q) for q in u)
        v,w=self.adapter.to_twist(*self.last_cmd)
        msg=Twist()
        msg.linear.x,msg.angular.z=float(v),float(w)
        self.pub.publish(msg)
        if self.observer_mode!='off':
            wl,wr,_=self.adapter.driver_applied(v,w)
            self.observer.command(self.get_clock().now().nanoseconds*1e-9,(wl,wr))
        return v,w

    def invalidate(self):
        self.generation+=1
        self.last_solution=self.last_solution_sim=self.last_solution_wall=None
        self.last_solution_input_sim=self.last_solution_input_wall=None
        self.next_solve=0.
        self.schedule.clear()
        self.active_predicted=None
        self.active_solve_id=None

    def job(self,*args,**kwargs):
        # Diagnostics only: when the single worker actually started this solve.
        started=time.monotonic()
        res=self.solve_job(*args,**kwargs)
        if isinstance(res,dict):
            res['job_start_wall']=started
            res['job_end_wall']=time.monotonic()
        return res

    def solve_job(self,generation,x,goal,v,w,forward,is_pose,disturbance=(0.,0.),obstacles=None,
                  goal_key=None,keep_warm=False):
        if self.worker_generation!=generation:
            self.mpc.reset()
            # INITIALIZING only: a missed first slot keeps this goal_id's warm start.
            if not (keep_warm and goal_key is not None and goal_key==self.worker_key):
                self.time_mpc.reset()
            self.worker_generation=generation
        # INITIALIZING only (keep_warm): also carry the last elastic iterate (see solver).
        self.time_mpc.carry_seed=bool(keep_warm and goal_key is not None and
                                      goal_key==self.worker_key)
        if goal_key is not None:
            self.worker_key=goal_key
        if is_pose and obstacles is not None:
            # Avoidance path only: a missed activation slot discards the late result
            # (generation) but keeps the warm start of the same goal_id, because a cold
            # constrained solve can exceed one slot and would otherwise never warm up.
            self.avoid_mpc.carry_seed=bool(keep_warm and self.avoid_worker_key==goal_key)
            if self.avoid_worker_key!=goal_key:
                self.avoid_mpc.reset()
                self.avoid_worker_key=goal_key
            return self.avoid_mpc.solve(x,goal,v,w,forward_only=forward,
                                        disturbance=disturbance,obstacles=obstacles)
        solver=self.time_mpc if is_pose else self.mpc
        if is_pose and self.time_backend=='acados':
            return solver.solve(x,goal,v,w,forward_only=forward,disturbance=disturbance)
        return solver.solve(x,goal,v,w,forward_only=forward)

    def report(self,state,reason='',result=MotionResult.RUNNING,dist=0.,ang=0.,**extra):
        gid=int(self.goal.goal_id) if self.goal is not None else 0
        data=dict(self.diag)
        if self.get_parameter('timing_trace').value:
            data['timing_trace']=self.timing_trace.snapshot()
        data.update(extra)
        data.update(state=state,reason=reason,goal_id=str(gid),
                    wheel_l=float(self.omega[0]),wheel_r=float(self.omega[1]),
                    profile_l=float(self.ref[0]),profile_r=float(self.ref[1]),
                    wheel_cmd_l=self.last_cmd[0],wheel_cmd_r=self.last_cmd[1],
                    feedback_age=self.feedback_age,feedback_enabled=self.wheel_feedback,
                    position_error=dist,heading_error=ang,
                    backend=data.get('backend') or (f'discrete_time_optimal_{self.time_backend}' if
                        self.goal is not None and self.goal.action=='GoToPose' else 'slsqp'))
        data['command_state_age_sim_s'] = (self.last_tick-self.last_solution_input_sim
            if state=='track' and self.last_solution_input_sim is not None else None)
        if self.response_calibration['applied']:
            data['motor_response'] = dict(sha256=self.response_calibration['sha256'],
                tau_left_s=self.params.m('tau_left'),tau_right_s=self.params.m('tau_right'))
        data['command_state_age_wall_s'] = (time.monotonic()-self.last_solution_input_wall
            if state=='track' and self.last_solution_input_wall is not None else None)
        data['active_solve_id']=self.active_solve_id if state=='track' else None
        data['compensated_state_age_sim_s']=(self.last_tick-self.last_solution_input_sim-self.dt
            if state=='track' and self.active_solve_id is not None else None)
        data['pose_receipt_age_sim_s'] = (max(0.,self.last_tick-self.pose_receipt_sim)
            if self.last_tick is not None and self.pose_receipt_sim is not None else None)
        data.update(observer_mode=self.observer_mode,
            observer_d_l=float(self.observer.d[0]),observer_d_r=float(self.observer.d[1]),
            observer_innovation_l=float(self.observer.innovation[0]),
            observer_innovation_r=float(self.observer.innovation[1]),
            observer_accepted=self.observer.accepted,observer_rejected=self.observer.rejected,
            wheel_stamp_valid=self.wheel_stamp_valid,
            wheel_source_age_s=(self.last_tick-self.wheel_source_sim if self.wheel_source_sim is not None else None),
            pose_source_age_s=(self.last_tick-self.pose_source_sim if self.pose_source_sim is not None else None),
            observer_valid=self.aligned_wheels is not None,
            pose_aligned=self.aligned_pose is not None)
        self.status_pub.publish(String(data=json.dumps(data)))
        if gid and self.goal.action=='GoToPose':
            msg=MotionResult()
            msg.header.stamp=self.get_clock().now().to_msg()
            msg.header.frame_id='map'
            msg.goal_id,msg.state,msg.reason=gid,result,reason
            msg.position_error,msg.heading_error=float(dist),float(ang)
            self.result_pub.publish(msg)

    def stop(self,reason,result=MotionResult.RUNNING,dist=0.,ang=0.):
        self.send((0.,0.))
        self.report('failed' if result==MotionResult.FAILURE else 'stop',
                    reason,result,dist,ang)

    def tick(self):
        wall=time.monotonic()
        now=self.get_clock().now().nanoseconds*1e-9
        elapsed=1/self.command_rate if self.last_tick is None else now-self.last_tick
        self.last_tick=now
        self.aligned_pose=None
        self.aligned_wheels=None
        self.observer_disturbance=np.zeros(2)
        if elapsed<0 or elapsed>.5:
            self.invalidate()
            self.arrival.reset()
            self.omega=self.ref=self.last_cmd=(0.,0.)
            self.observer.reset()
            self.aligned_pose=None
            self.wheel_source_sim=None
            self.wheel_stamp_valid=False
            self.measured=self.measured_time=None
            self.pose_source_sim=None
            return self.stop('clock discontinuity')
        self.omega,self.ref=motor_step(self.params,self.omega,self.ref,self.last_cmd,elapsed)
        self.feedback_age=None if self.measured_time is None else wall-self.measured_time
        feedback=self.feedback_age is not None and self.feedback_age<.2
        if feedback:
            self.omega=self.measured
        if self.observer_mode!='off' and feedback:
            estimate=self.observer.current(now)
            if estimate is not None:
                self.aligned_wheels,self.observer_disturbance=estimate
                if self.pose_valid and self.pose_source_sim is not None:
                    aligned=self.observer.align_pose(self.pose,self.pose_source_sim,now)
                    if aligned is not None:
                        self.aligned_pose=aligned[:3]
        # Drain a finished job even when cancelled or stopped. Never use an old generation.
        if self.future is not None and self.future.done():
            future=self.future
            generation=self.future_generation
            submitted=self.future_wall
            submitted_sim=self.future_sim
            completed_id=self.solve_id
            scheduled=self.future_scheduled
            predicted=self.future_predicted
            self.future=None
            try:
                res=future.result()
            except Exception as exc:
                res={'ok':False,'status':-1,'ms':(wall-submitted)*1000,
                     'message':str(exc),'residuals':[]}
            self.timing_trace.completed(completed_id,self.future_goal_id,generation,self.generation,
                submitted,submitted_sim,self.future_due,res,wall)
            if generation==self.generation:
                activation_diag={k:v for k,v in self.diag.items() if k.startswith('activation_') or k=='prediction_lead_sim_s'}
                self.diag={k:res.get(k) for k in ('status','ms','direction','residuals',
                                                'iterations','v_bound','w_bound','message','backend',
                                                'horizon_steps','planned_time','terminal_feasible',
                                                'attempts','lower_steps','attempt_statuses','replay_violation',
                                                'damping_cost','damping_scale','forecast_disturbance')}
                self.diag.update(activation_diag)
                self.diag.update(solve_id=completed_id,
                                 solve_input_age_sim_s=now-submitted_sim,
                                 solve_input_age_wall_s=wall-submitted)
                if res.get('job_start_wall') is not None:
                    # Queue wait before the worker started, and the delay until this tick
                    # collected the finished result (ROS timer / GIL scheduling).
                    self.diag.update(worker_wait_ms=(res['job_start_wall']-submitted)*1e3,
                                     result_pickup_ms=(wall-res['job_end_wall'])*1e3,
                                     acados_ms=sum(a.get('acados_ms',0.) for a in
                                                   res.get('attempt_statuses') or []))
                if scheduled:
                    # Hold the existing stage until its scheduled boundary.
                    # The new solution is only eligible for that boundary.
                    if res['ok'] and wall-submitted<=.3:
                        self.schedule.offer(now,(res,predicted,submitted_sim,submitted,completed_id))
                elif res['ok'] and wall-submitted<=.3:
                    self.last_solution=tuple(res['u'])
                    self.last_solution_sim=now
                    self.last_solution_wall=wall
                    self.last_solution_input_sim=submitted_sim
                    self.last_solution_input_wall=submitted
                    self.failures=0
                    self.publish_path(res['xs'])
                else:
                    self.last_solution=None
                    self.failures+=1
        fresh=(self.goal is not None and wall-self.goal_time<=self.goal_timeout
               and self.pose is not None and wall-self.pose_time<=self.pose_timeout)
        if not fresh or self.goal.mode==BehaviorGoal.STOP:
            if self.key is not None:
                self.invalidate()
                self.key=None
            self.arrival.reset()
            self.diag={}
            return self.stop('STOP goal' if fresh else 'stale input')
        t=self.goal.target
        goal=(t.x,t.y,t.theta)
        is_pose=self.goal.action=='GoToPose'
        avoid=obstacle_snapshot.AvoidanceOptions(
            bool(self.goal.avoid_walls),bool(self.goal.avoid_opponents),
            bool(self.goal.avoid_ball)) if is_pose else obstacle_snapshot.AvoidanceOptions()
        key=(self.goal.action,int(self.goal.goal_id),avoid)
        if key!=self.key:
            self.avoid=avoid
            self.key=key
            self.invalidate()
            self.arrival.reset()
            self.diag={}
            self.failures=0
            self.failed_reason=None
            self.progress_time=now
            self.progress_best=None
            self.tracking=False
            self.init_start=now
            self.init_missed=0
            self.timing_trace.goal(self.goal.goal_id)
        if not self.pose_valid or not all(math.isfinite(v) for v in goal):
            self.arrival.reset()
            self.invalidate()
            return self.stop('invalid localization or target')
        if is_pose and not self.wheel_feedback:
            return self.stop('GoToPose requires verified wheel_feedback:=true',MotionResult.FAILURE)
        if self.wheel_feedback and not feedback:
            self.arrival.reset()
            self.invalidate()
            return self.stop('stale wheel feedback')
        if is_pose and self.observer_mode!='off' and self.aligned_wheels is None:
            self.arrival.reset()
            self.invalidate()
            return self.stop('wheel timestamp history unavailable')
        if self.failed_reason is None and self.avoid.any:
            self.failed_reason=self.avoidance_precheck(goal)
            if self.failed_reason is not None:
                self.invalidate()
        if self.failed_reason is not None:
            return self.stop(self.failed_reason,MotionResult.FAILURE)
        if self.avoid.any:
            self.diag['avoidance']=self.avoid_snapshot(now).describe()
            self.diag['min_clearance_m']=self.current_clearance()
        l,r=self.omega
        v_actual=(self.mpc.rl*l+self.mpc.rr*r)/2
        w_actual=(self.mpc.rr*r-self.mpc.rl*l)/self.mpc.b
        inside,done,dist,ang=self.arrival.update(now,self.pose,goal,
                 max(abs(v_actual),self.world_v),w_actual,self.omega,feedback)
        if is_pose and inside and self.arrival.since is not None:
            # Braking to zero is not a P alignment controller; if we drift out,
            # tracking resumes immediately with the same NMPC.
            if (self.last_solution is not None or self.schedule.due is not None or
                    (self.future is not None and self.future_generation==self.generation)):
                self.invalidate()
            self.send((0.,0.))
            return self.report('arrived' if done else 'settle','settled' if done else 'waiting for rest',
                               MotionResult.SUCCESS if done else MotionResult.RUNNING,dist,ang)
        if is_pose:
            merit=dist+.05*ang
            if self.progress_best is None or merit<self.progress_best-.005:
                self.progress_best,self.progress_time=merit,now
            if self.failures>=3:
                self.failed_reason='three consecutive optimizer failures'
            elif now-self.progress_time>4.:
                self.failed_reason='no pose progress for 4 s'
            if self.failed_reason:
                self.invalidate()
                return self.stop(self.failed_reason,MotionResult.FAILURE,dist,ang)
        if self.future is not None and wall-self.future_wall>.3:
            if self.future_generation==self.generation:
                self.invalidate()
                if self.tracking or not is_pose:
                    self.failures+=1
            return self.stop('solver deadline')
        if is_pose and self.time_backend=='acados':
            return self.scheduled_tick(now,wall,goal,dist,ang,elapsed)
        if self.future is None and now+1e-8>=self.next_solve:
            v,w=self.caps()
            x=(*self.pose,*self.omega,*self.last_cmd)
            self.future_generation=self.generation
            self.future_wall=wall
            self.future_sim=now
            self.future_scheduled=False
            self.future_goal_id=self.goal.goal_id
            self.future_due=None
            self.future_predicted=None
            self.solve_id+=1
            self.future=self.executor_pool.submit(self.job,self.generation,x,goal,v,w,
                                                   self.goal.action in self.forward_only,is_pose)
            self.next_solve=now+self.dt
        valid=(self.last_solution is not None and now-self.last_solution_sim<=2*self.dt
               and wall-self.last_solution_wall<=.3)
        v,w=self.send(self.last_solution if valid else (0.,0.))
        self.report('track' if valid else 'waiting', 'optimized' if valid else 'no fresh optimized command',
                    dist=dist,ang=ang,v=v,w=w,period_s=elapsed)

    def scheduled_tick(self,now,wall,goal,dist,ang,elapsed):
        """Pipeline exactly one 100 ms stage; optimize the next activation state."""
        scheduled_due=self.schedule.due
        had_offer=self.schedule.ready is not None
        was_tracking=self.tracking
        due,result,jitter=self.schedule.take(now)
        if due:
            self.diag['activation_jitter_sim_s']=float(jitter)
            if result is not None:
                res,predicted,submitted_sim,submitted,solve_id=result
                if self.avoid.any and not self.activation_safe(res):
                    # Latest obstacles collide with this plan: brake for this slot.
                    result=None
            if result is not None:
                if not self.tracking:
                    self.tracking=True
                    self.diag['activation_first_s']=now-self.init_start
                    self.diag['init_missed']=self.init_missed
                self.active_solve_id=solve_id
                self.last_solution=tuple(res['u'])
                self.last_solution_sim=now
                self.last_solution_wall=wall
                self.last_solution_input_sim=submitted_sim
                self.last_solution_input_wall=submitted
                self.active_predicted=predicted
                self.failures=0
                self.diag.update(activation_position_error_m=math.hypot(
                    self.pose[0]-predicted[0],self.pose[1]-predicted[1]),
                    activation_heading_error_rad=abs(wrap(self.pose[2]-predicted[2])),
                    activation_wheel_error_rad_s=float(np.max(np.abs(
                        np.asarray(self.omega)-predicted[3:5]))))
                self.diag.update(
                    activation_aligned_position_error_m=(float(np.linalg.norm(self.aligned_pose[:2]-predicted[:2]))
                        if self.aligned_pose is not None else None),
                    activation_aligned_heading_error_rad=(abs(wrap(self.aligned_pose[2]-predicted[2]))
                        if self.aligned_pose is not None else None),
                    activation_aligned_wheel_error_rad_s=(float(np.max(np.abs(self.aligned_wheels[:2]-predicted[3:5])))
                        if self.aligned_wheels is not None else None))
                self.publish_path(res['xs'])
            else:
                # No valid solution for this interval: brake, not an old first input.
                self.last_solution=None
                self.active_predicted=None
                self.active_solve_id=None
                if self.tracking:
                    self.failures+=1
                else:
                    self.init_missed+=1
                self.diag.update(activation_position_error_m=None,
                    activation_heading_error_rad=None,activation_wheel_error_rad_s=None,
                    activation_aligned_position_error_m=None,activation_aligned_heading_error_rad=None,
                    activation_aligned_wheel_error_rad_s=None,activation_missed=True)
                # Invalidate a late worker so it cannot fill a subsequent slot.
                self.generation+=1
            self.diag['activation_missed']=result is None
            self.timing_trace.activation(now,scheduled_due,jitter,result is not None,
                had_offer,was_tracking,self.solve_id if self.future is not None else None,wall)
        if not self.tracking and now-self.init_start>self.init_timeout:
            self.failed_reason=(f'no optimized first command within {self.init_timeout:g} s '
                                f'({self.init_missed} slots missed while initializing)')
            self.invalidate()
            return self.stop(self.failed_reason,MotionResult.FAILURE,dist,ang)
        if self.failures>=3:
            self.failed_reason='three consecutive missed/failed activation slots'
            self.invalidate()
            return self.stop(self.failed_reason,MotionResult.FAILURE,dist,ang)
        command=self.last_solution if self.last_solution is not None else (0.,0.)
        # Send before snapshotting prediction: this is the known held command.
        v,w=self.send(command)
        if self.schedule.due is None and self.future is None:
            vb,wb=self.caps()
            physical=np.asarray((*self.pose,*self.omega,*self.ref),float)
            disturbance=np.zeros(2)
            applied=command
            if self.observer_mode!='off':
                if self.aligned_wheels is not None:
                    physical[3:7]=self.aligned_wheels
                    disturbance=self.observer_disturbance.copy()
                if self.aligned_pose is not None:
                    physical[:3]=self.aligned_pose
                applied=self.adapter.driver_applied(v,w)[:2]
            predicted=self.time_mpc.predictor.step(physical,applied,self.dt,
                                                  disturbance=disturbance)
            # A bounded transient forecast avoids imposing a constant nonzero
            # disturbance at the stop equilibrium for the entire long horizon.
            forecast=disturbance*math.exp(-self.dt/FORECAST_TAU)
            state=np.r_[predicted,command]
            self.schedule.begin(now)
            self.future_generation=self.generation
            self.future_wall=wall
            self.future_sim=now
            self.future_goal_id=self.goal.goal_id
            self.future_due=self.schedule.due
            self.future_scheduled=True
            self.future_predicted=predicted
            self.solve_id+=1
            obstacles=self.avoid_snapshot(now) if self.avoid.any else None
            self.future=self.executor_pool.submit(self.job,self.generation,state,
                 goal,vb,wb,self.goal.action in self.forward_only,True,tuple(forecast),obstacles,
                 self.key,not self.tracking)
            self.diag['prediction_lead_sim_s']=self.dt
        valid=self.last_solution is not None
        self.report('track' if valid else ('waiting' if self.tracking else 'initializing'),
                    'scheduled optimized input' if valid else 'waiting for scheduled solution',
                    dist=dist,ang=ang,v=v,w=w,period_s=elapsed,tracking=self.tracking,
                    init_missed=self.init_missed)

    # ------------------------------------------------------------------ avoidance
    def avoid_snapshot(self,now):
        return obstacle_snapshot.take(self.avoid,self.avoid_config,self.avoid_field,
                                      self.avoidance_world(),now)

    def avoidance_precheck(self,goal):
        """Reasons an avoidance request cannot run (None: it can)."""
        if self.avoid_mpc is None:
            return 'avoidance options require mpc_backend:=acados'
        if self.avoid.walls:
            names,clear=obstacle_snapshot.take(self.avoid,self.avoid_config,
                                               self.avoid_field).clearances(goal)
            if clear.size and float(clear[0,0])<self.avoid_config.margin:
                return (f'target footprint {float(clear[0,0])*100:.1f} cm from walls/goal; '
                        f'needs {self.avoid_config.margin*100:.1f} cm')
        return None

    def current_clearance(self):
        if self.pose is None:
            return None
        _,clear=self.avoid_snapshot(0.).clearances(self.pose)
        return float(np.min(clear)) if clear.size else None

    def activation_safe(self,res):
        """Re-check a scheduled plan against the latest obstacles before applying it."""
        xs=np.asarray(res.get('xs',[]),float)
        if xs.ndim!=2 or not len(xs):
            return False
        snap=self.avoid_snapshot(self.last_tick or 0.)
        _,clear=snap.clearances(collision_geometry.interpolate_poses(xs))
        if not clear.size:
            return True
        required=np.minimum(self.avoid_config.margin,clear[0]-1e-3)
        ok=bool(np.all(clear>=required[None,:]-1e-6))
        self.diag['activation_collision_rejected']=not ok
        return ok

    def publish_path(self,xs):
        path=Path()
        path.header.stamp=self.get_clock().now().to_msg()
        path.header.frame_id='map'
        for x in xs:
            ps=PoseStamped()
            ps.header=path.header
            ps.pose.position.x,ps.pose.position.y=float(x[0]),float(x[1])
            ps.pose.orientation.z,ps.pose.orientation.w=math.sin(x[2]/2),math.cos(x[2]/2)
            path.poses.append(ps)
        self.path_pub.publish(path)


def main(args=None):
    rclpy.init(args=args)
    node=MpcController()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt,rclpy.executors.ExternalShutdownException):
        pass
    finally:
        if rclpy.ok():
            node.send((0.,0.))
        node.executor_pool.shutdown(wait=True,cancel_futures=True)
        node.destroy_node()
        rclpy.try_shutdown()

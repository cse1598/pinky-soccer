# 무인 진행 보고 — 판단·월드 모델 기반 구축 (2026-11-21, [claude])

지시문: `Claude outputs/claude_code_prompt.md` (Phase 1~7, 사전 결정표 D1~D13). 이 파일과 `docs/overnight/`는 git에서 제외되어 있습니다. Phase별 진행 메모 원본은 `docs/overnight/progress_notes.md`에 있습니다.

## ① 한 줄 요약

월드 모델 → 행동 트리 → 제어 → UI 계층을 새 패키지 5개와 `pinky_soccer` 제어기로 끝까지 연결했습니다. 새 테스트 62개는 모두 통과했습니다. MuJoCo 혼자 골 넣기 시험은 공 기본 위치에서 **4.5초 만에 골**, 공 (0.5, 0.3)에서는 **120초 실패**(주원인: odom만 쓰는 자기 위치가 회전·충돌 뒤 0.6 m 틀어짐)입니다. 로컬 커밋 7개, push는 하지 않았습니다.

## ② Phase별 결과

| Phase | 결과 | 빌드·테스트 | 커밋 |
|---|---|---|---|
| 0 현황 확인 | 완료 (이전 세션) | — | — |
| 1 아키텍처 문서 | 완료 | — | `7bc2675` |
| 2 저장소 위생·보호 장치 | 완료 | 훅 10개 시나리오, deny 3경로 거부 확인, 전체 빌드 성공 | `84035ea` |
| 3 `pinky_soccer_field` | 완료 | 11 passed | `64dfe2c` |
| 4 `pinky_soccer_msgs` | 완료 | 빌드·Python 생성 확인 | `79362c8` |
| 5 월드 모델·BT·제어기 | 완료 | bt 21, world_model 12, pinky_soccer 7(+1 skip) | `733f906` |
| 6 UI `pinky_soccer_viz` | 완료 (RViz2 화면은 미확인) | 10 passed, headless 토픽·PNG 확인 | `e2ed183` |
| 7 마무리·시험 | **부분** (시험 B 실패) | 전체 24 패키지 빌드, 새 테스트 62개 통과 | `42a39eb` |

### Phase 1
- `docs/ARCHITECTURE.md`: 부록 A를 실제에 맞춰 고침. 시뮬레이터도 `command_watchdog`를 거침, `/ground_truth`는 MuJoCo의 로봇 자세만, IMU/초음파는 옵션, `map` 프레임 없음. 토픽 표를 추가했습니다.
- 루트 README에 링크를 걸고, `AGENTS.md`·`CLAUDE.local.md`에 한 줄씩 추가했습니다(D4).

### Phase 2
- `refs/robocup_demo`(Apache-2.0)와 `refs/BHumanCodeRelease`(404 MB)를 클론하고 `refs/COLCON_IGNORE`를 두었습니다.
  - `.gitignore`에 `refs/`, `.ignore`에 `!refs/`를 넣었습니다. `rg`로 refs 안이 검색되는 것을 확인했습니다.
- **B-Human 라이선스**
  - 재배포하면 저작권 고지와 "This product includes software developed by B-Human" 표기가 필요합니다.
  - RoboCup 대회에서 일부라도 쓰면 첫 대회 1개월 전에 HSL 메일링 리스트에 공지해야 합니다.
  - 주요 부분을 쓰면 파생 소프트웨어로 보고 연말 공개 의무가 생깁니다. Nao Devils 파일은 별도 라이선스입니다.
  - → 구조와 아이디어만 참고하고 코드는 복사하지 않았습니다.
- **BehaviorTree.ROS2**
  - Jazzy에 apt 패키지가 없어(D3) submodule로 넣고 **태그 `0.3.0`(`72a3bf5`, 2025-10-30)**에 고정했습니다.
  - 근거: 마지막 릴리스 태그이고, `behaviortree_cpp` 4.11.0과 빌드됩니다.
  - HEAD는 그 뒤로 2커밋뿐이고, 둘 다 우리가 쓰지 않는 액션 노드 관련입니다.
  - 예제 패키지(`btcpp_ros2_samples`)도 함께 빌드됩니다. 건너뛰려면 `--packages-skip btcpp_ros2_samples`를 쓰면 되고, README에 적었습니다.
- **`.claude/settings.json`**
  - `Edit(/refs/**)`, `Edit(/src/BehaviorTree.ROS2/**)`, `Edit(/src/pinky_pro/**)`를 deny로 막았습니다.
  - 문법은 현재 공식 문서로 확인했습니다: `/`는 프로젝트 루트 기준이고, Edit 규칙이 Write와 NotebookEdit도 막습니다.
  - 세 경로 모두 실제 Write 시도가 거부되는 것을 확인했습니다.
  - Bash/Python 하위 프로세스의 파일 쓰기는 막지 못합니다(문서 명시).
- **`.githooks/pre-commit`**
  - `core.hooksPath`를 설정하고 README 빌드 절에 한 줄을 추가했습니다.
  - 임시 저장소에서 10개 시나리오가 기대대로 동작했습니다.
- **기존 빌드 캐시 문제 2건 (모두 삭제 없이 해결)**
  - `pinky_gz_sim`이 업그레이드 전 `libgz-physics7.so.7.8.0`을 참조 → `--cmake-force-configure`로 재구성했습니다.
  - `build/pinky_interfaces/.../pinky_interfaces`가 2026-11-19 비-symlink 빌드의 잔재 → scratchpad로 **옮겼습니다**.

### Phase 3
- `Field` 클래스: 골대(입구·뒤·내부), 외벽 안쪽, 경기 구역, 페널티 구역, 중앙 원, 중립점, `our_goal_color` → `own_goal`/`opp_goal`/`attack_sign`, `ball_in_goal`.
- `load_spec()`은 sim 검증 규칙을 복제했고, sim 로더와 판정이 같은지 테스트합니다.
- **`generate_field_map`**
  - URDF에서 라이다 높이 0.125 m를 계산합니다. 외벽만 점유로 그립니다(골대 0.11 m는 라이다보다 낮음).
  - 결과: 255×194칸(0.01 m), origin (−1.275, −0.970).
  - 산출물은 재생성할 수 있어 커밋하지 않았습니다.
- AMCL 대칭 문제와 대응(킥오프 초기 자세, 골대 색 보정)을 README에 적었습니다.

### Phase 5
- **`ball_detector`**: HSV 색 검출 → 광선 → 바닥 z = 공 반지름 평면과 교차 → `base_link`.
  - 내부 파라미터는 `camera_yaml`/보정 프로필 → `camera_info` 순으로 씁니다.
  - 실물 영상 방향용 `image_rotated_180` 옵션이 있습니다.
- **`world_model_node`**
  - 자기 위치: `odom_only` 또는 `tf`.
  - 공: 마찰 감쇠 칼만 필터(게이트, 재획득, 벽 제한).
  - OBSERVED/ESTIMATED/LOST는 경과 시간과 공분산으로 정합니다.
  - 탐색 그리드(시야 부채꼴), 라이다 상대 군집, `/game/playing`.
- **`fake_world_model`**: `/cmd_vel`을 적분해 움직이고, 공 상태가 순환합니다.
- **`pinky_soccer_bt`**
  - 부록 C XML에 발행 전용 `PublishGoal` 트리를 더했습니다.
  - `ReadWorldModel` = `RosTopicSubNode`, `PublishBehaviorGoal` = `RosTopicPubNode`.
  - 모든 노드가 실제 계산을 합니다(D8). 기하 계산은 ROS와 분리해 gtest로 검사합니다.
  - 실제 XML을 로드하는 시나리오 테스트 7개가 있습니다.
- **`reactive_controller`**: 비례 제어, STOP, 목표·자세 타임아웃 0.5 s. `hello_node.py`는 그대로 뒀습니다(D9).
- **통합**: fake → bt → controller에서 `/world_model` 29.9 Hz, 분기 전환, `/cmd_vel` 발행을 확인했습니다.

### Phase 6
- RViz 마커(경기장 latched), OpenCV 탑뷰(패널, PNG 스냅숏), `rviz/soccer.rviz`, `sim_viz`/`sim_field` launch를 만들었습니다.
- 평가 도구: `mujoco_eval_bridge`(공 실제 위치), `soccer_trial`(골 판정 JSON).
- `sim_viz gui:=false` 실행 결과: 탑뷰 9.9 Hz, 마커 29.8 Hz, latched 마커 12개, 탐색 그리드 49×37.
- 고친 버그: 마커 scale 정수로 인한 abort, 히트맵 uint8 오버플로, 패널 글자 겹침, fake `last_seen` 시각, 종료 시 publish 예외.

### Phase 7
- **공 검출** (`sim_field`, headless):
  - MuJoCo: 공 (0.3, 0)을 x=0.311로 검출, 14.3 Hz, `/world_model` 공 OBSERVED.
  - Gazebo: x=0.302, 10.2 Hz, OBSERVED.
- **혼자 골 넣기** (MuJoCo, 상대 없음, 로봇 원점, sim 시간 최대 120 s, 판정은 `/sim/ball_ground_truth`):

| 경우 | 결과 | 시간 | 분기 흐름 |
|---|---|---|---|
| A 공 (0.3, 0.0) | **골** | 4.51 s | STOP → PushBall → (공이 굴러 x=1.100 통과) |
| B 공 (0.5, 0.3) | **실패** (시간 초과) | 120 s | GoBehindBall → 공 LOST → Search 회전 중 공을 쳐냄 → odom 드리프트 → DEFEND/FaceBall에 머묾 |

- **시험 B 원인** (진단 재실행 `trialB_rerun_60s_diag.json`):
  1. **odom_only 드리프트**(주원인): 제자리 회전과 벽 접촉 뒤 t=16 s에 실제 (0.35, 0.72) vs 추정 (0.27, 0.12)으로 0.6 m 오차. GoToPose가 엉뚱한 방향으로 몰아 벽에 붙고, 자세 오차 때문에 벽 점이 상대로 오검출됩니다(DEFEND 유발 추정).
  2. **공 거리 편향**: MuJoCo에서 0.58 m 거리 공을 약 6 cm 멀게 추정합니다(거리에 비례). Gazebo는 2 mm 오차라 MuJoCo 카메라 렌더와 `camera_info` 불일치가 의심됩니다(미확인, Codex에 확인 요청).
  3. **근거리 사각지대**: 공에 0.15 m 안으로 다가가면 시야 아래로 빠져 ESTIMATED → LOST가 됩니다. 이어지는 탐색 회전에서 공을 쳐냅니다.
  4. **MuJoCo 공이 멈추지 않음**: 공이 0.1~0.15 m/s로 100초 넘게 계속 구릅니다(구름 저항 없음 추정).
- **다음 시도**: AMCL(`localization:=tf`)과 생성 지도로 드리프트 제거, 근거리에서는 공을 LOST로 바로 넘기지 않기(예측 유지 시간 연장 또는 "공이 범퍼 앞에 있음" 상태), GoBehindBall 우회 경로에서 공 피하기, MuJoCo 카메라 내부 파라미터 확인.
- 튜닝에는 1시간 이상 쓰지 않았습니다.
- **산출물**(`docs/overnight/`): `trialA_push.png`, `trialA_after_goal.png`, `trialB_ball_range_bias.png`, `trialB_ball_lost_near.png`, `trialB_odom_drift.png`, `trialB_late.png`, `sim_viz_topview.png`, 결과 JSON 3개.

## ③ 대신 결정한 것과 이유

1. **pre-commit 허용 변수**: BT.ROS2 submodule을 처음 추가하는 커밋은 훅 규칙 (a)에 걸립니다. 그래서 `PINKY_ALLOW_SUBMODULE=<경로>`를 명시할 때만 포인터 변경을 허용하는 변수를 만들었습니다. `--no-verify`를 쓰지 않으려는 선택입니다. 사람이 지시한 업그레이드에만 쓰도록 README에 적었습니다.
2. **발행 전용 트리**: 액션은 목표를 루트 블랙보드 `goal`에 쓰고, `bt_node`가 매 주기 별도 `PublishGoal` 트리(`RosTopicPubNode`)를 tick합니다. `RosTopicPubNode`는 SUCCESS만 돌려주는 조건 노드라서, RUNNING 액션과 같은 트리에 두면 Timeout 같은 탐색 순서가 깨지기 때문입니다. 부록 C의 메인 트리는 그대로입니다.
3. **`IsBehindBall` 판정 방식**: "뒤 offset 지점과의 거리" 대신 "슛 선 기준"(공 뒤 0.30 m 이내, 옆 `tol_dist`, 방향 `tol_angle`)으로 판정합니다. 밀기 시작하면 offset 지점에서 멀어져 Shoot↔GoBehindBall이 떨리기 때문입니다.
4. **`GoBehindBall` 단순 우회점**: 공 옆 0.20 m를 거치게 했습니다. 로봇이 공 앞에 있을 때 공을 우리 골대 쪽으로 미는 것을 최소한 막기 위함입니다. 충돌 검사는 여전히 TODO입니다.
5. **`GoToBlockPoint` 히스테리시스**(0.05/0.10 m): 통합 시험에서 FaceBall과 떨리는 것을 확인했기 때문입니다.
6. **`TurnToLastSeen`·`SpinInPlace` 의미**: TurnToLastSeen은 마지막 방향을 보면 FAILURE를 돌려 다음 탐색 단계로 넘깁니다. SpinInPlace는 목표 방향을 1 rad 앞에 계속 두고, `max_speed`를 회전 속도 상한으로 씁니다. 목표가 자세 하나뿐인 메시지에서 회전을 표현하기 위함입니다.
7. **공 실제 위치**: 어디에도 발행되지 않아서 `pinky_soccer_sim`을 고치지 않고(D13) 평가 전용 wrapper가 실행 중 `Bridge.publish_state`를 확장하게 했습니다. `sim_field.launch.py eval_ball_truth:=true`가 sim launch의 브리지 Node를 바꿉니다. launch_ros 내부 속성에 의존하므로 버전이 바뀌면 명시적 오류를 냅니다.
8. **지도 산출물**은 커밋하지 않았습니다(재생성 가능, `maps/` 처리가 미결정).
9. **수치 기본값**: 탐색 그리드 0.05 m, 카메라 시야 fallback 60°, 시야 거리 0.15~1.5 m, 필터 수치, HSV `[5,120,80]–[25,255,255]`, 제어 이득 모두 가정이며 YAML 주석에 표시했습니다.
10. **`BallInOwnHalf` margin 해석**: "우리 쪽 절반이 중앙선을 넘어 `margin`만큼 확장"으로 해석했습니다.
11. **`GoToBlockPoint` ratio 기준**: `ratio`를 우리 골대 쪽에서 잽니다 (0.35 = 골대에 가까운 쪽).

## ④ 결정해 주실 것

1. **`NotFacingOwnGoal min_angle=1.57`**(부록 값)은 상대 진영 구석(예: 공 (1.0, 0.7))의 정상 슛도 막습니다. 1.0 근처로 줄일지 정해 주세요. 자책골 방지는 "슛 방향은 항상 상대 쪽 x 성분"이라는 성질로 따로 보장됩니다(테스트 있음).
2. **메시지 개선 제안**(D6: 초안대로 만들었고 제안만 합니다):
   - (a) `BehaviorGoal`에 `angular_speed`(회전 탐색용)를 두거나 SPIN mode를 추가.
   - (b) `TrackedObject`에 `velocity_covariance`를 추가.
   - (c) `WorldModel.self`의 `ESTIMATED` 의미를 정의 (AMCL 수렴 전 등).
   - (d) branch를 문자열 대신 상수로.
3. **다음 우선순위**: AMCL 연동 vs 근거리 사각지대·우회 경로 vs 수치 튜닝 중 무엇을 먼저 할지.
4. **경기장 YAML 원본 이동**(D10, STATUS 메시지에 제안을 남김): 동의 여부.
5. **`maps/`·원본 실험 폴더**: 이 실행 전에 휴지통으로 옮겨져 있었습니다. 직접 하신 것인지, 버릴 것인지 알려 주세요.

## ⑤ 사용자 할 일

- **push**: 로컬 커밋 9개(이전 Codex 2개 + 이번 7개)가 `origin/main`보다 앞서 있습니다. 확인 후 직접 push 해 주세요. submodule이 새로 생겼으므로 다른 PC에서는 `git submodule update --init`이 필요합니다.
- **용량 정리**(되돌릴 수 없어 실행하지 않음):
  1. 도달 불가 13.7 GB(비압축) blob과 `tmp_pack_*`를 정리하려면 `git reflog expire --expire-unreachable=now --all && git gc --prune=now`. **먼저** Codex 체크포인트 `refs/codex/turn-diffs/...`가 필요 없는지 확인하세요.
  2. `log/`의 오래된 빌드 로그(약 32 MB, 130여 개) 정리.
  3. `.vscode/browse.vc.db`(1.4 GB): `.vscode/settings.json`에 `"C_Cpp.default.browse.databaseFilename"`을 저장소 밖 경로로 두거나, `"C_Cpp.files.exclude"`에 `build/`·`install/`·`log/`·`refs/`를 추가.
- scratchpad로 옮긴 옛 빌드 디렉터리(`/tmp/claude-1000/-home-cse-pinky-soccer/2124eb62-8926-4415-8d5e-cc0322b5c438/scratchpad/stale_build/`)는 필요 없으면 지워도 됩니다.
- **화면 확인**: `ros2 launch pinky_soccer_viz sim_viz.launch.py`로 RViz2와 rqt_image_view 화면을 확인해 주세요. 이번에는 GUI를 띄우지 않았습니다.

### 실제 로봇에서 확인할 것

1. 카메라 영상 방향(180° 회전 여부)과 `front_camera_optical_frame` TF → 그에 맞춰 `ball_detector`의 `image_rotated_180` 설정.
2. 카메라 내부 보정 후 `camera_info` K 적용 여부. K=0이면 검출기가 동작하지 않습니다.
3. 실제 주황 골프공과 경기장 조명에서 HSV 범위, 최소 면적, 원형도.
4. 알려진 거리(0.3/0.6/1.0 m)에 공을 놓고 `/ball_detection` 거리 오차 측정. 시뮬레이션의 거리 비례 편향과 비교합니다.
5. 공 근거리 사각지대가 실제로 몇 cm부터인지 (카메라 기울기 8° 가정).
6. 카펫 위 골프공 구름 감속 → `ball.friction_tau`.
7. odom 드리프트(제자리 회전, 공·벽 접촉) 정도. AMCL 필요성의 근거가 됩니다.
8. `reactive_controller` 이득과 상한이 실제 모터·watchdog과 맞는지.

## ⑥ 남은 TODO

- AMCL 연동: `localization:=tf`, `generate_field_map` 지도, 킥오프 초기 자세, 공식 Nav2 params wrapper.
- 카메라로 본 골대 색으로 180° 뒤집힘 검증.
- Nav2 연동: NAVIGATE mode, `planned_path` 채우기.
- 근거리 공 처리, GoBehindBall 우회 경로의 공 충돌 회피, 상대 추적(ID·속도)과 가림 처리.
- 탐색 그리드의 가림 처리, 시야 거리 범위를 카메라 TF에서 계산.
- 수치 튜닝(BT XML, 필터, 제어기), Groot2 화면 확인.
- MuJoCo 카메라 내부 파라미터와 렌더의 일치 확인 (Codex 메시지).
- 1대1을 위한 namespace(기존 남은 작업).

## ⑦ 커밋 목록 (main, 로컬, push 없음)

```
42a39eb fix: make sim_field evaluation bridge swap work and enrich trial trace
e2ed183 feat: add world model UIs, simulation launches and trial tools
733f906 feat: add world model, behavior tree and reactive controller
79362c8 feat: add pinky_soccer_msgs for world model and behavior goals
64dfe2c feat: add pinky_soccer_field geometry and LiDAR map generator
84035ea chore: add repository guards and BehaviorTree.ROS2 submodule
7bc2675 docs: add decision-layer architecture document
```

모든 커밋은 pre-commit 훅을 통과했습니다. `84035ea`만 `PINKY_ALLOW_SUBMODULE=src/BehaviorTree.ROS2`로 submodule 추가를 허용했습니다. 이 커밋들에는 `.agents/`, `AGENTS.md`, `CLAUDE.local.md`, `Claude outputs/`, `refs/`, 이 보고서가 포함되지 않았습니다.

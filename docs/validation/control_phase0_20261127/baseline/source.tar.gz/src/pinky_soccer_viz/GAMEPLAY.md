# 실물·Gazebo·MuJoCo 경기 실행

현재 기본 rectangle 경기는 [경기 준비·LED 절차](../../docs/MATCH_PREPARATION.md)를 먼저 수행합니다. 준비 신호와 경기 시작은 분리되며 READY 전에는 시작이 차단됩니다. 실물 robot_host 통합 실행에는 새 자체 bringup 배포가 필요합니다.

세 환경 모두 `game.launch.py` 실행 → RViz 경기장 모니터 → 시작 신호 → 자동 플레이 순서입니다.

기본 `headless:=false`이면 **RViz와 카메라 창이 함께 열립니다.** 카메라 창은
왼쪽 **원본**, 가운데 **경기 알고리즘의 공 원/중심 표시**, 오른쪽 **주황색 선택 마스크**를
동일 프레임 시각으로 나란히 표시합니다. 노란 골대/책상이 마스크에서 흰색인지와
가운데 원이 실제 공에 겹치는지 확인하세요. 아직 처리되지 않은 프레임은 WAITING,
0.5초 넘게 끊긴 영상은 STALE로 표시합니다. Q/ESC나 닫기 버튼은 카메라 창만 닫고
경기는 계속하므로 경기 정지는 기존 시작/정지 신호로 합니다. `headless:=true`는 두 GUI를 끕니다.

로봇이 여러 대면(시뮬 `robots:=2 opponent_mode:=game`) 카메라 창에서 **1~9 키 또는 Tab**으로
보여 줄 로봇을 고릅니다(처음은 내 로봇, 원본 패널 제목에 `[robot 1/2: yellow]` 표시). 선택한
로봇의 토픽만 구독합니다. MuJoCo 장애물 모드(static/lateral/longitudinal) 상대는 검출기가 없어
시뮬 카메라 원본(`/<상대>/sim/camera/image_raw`)만 나오고, 이 영상은 창이 볼 때만 렌더링합니다
(`opponent_camera`). Gazebo 장애물 상대는 카메라가 없어 목록에 없습니다. 직접 실행할 때는
`ros2 run pinky_soccer_viz game_camera_view --ros-args -p robots:='[yellow, blue]'`.

창을 닫았다가 다시 열려면 같은 ROS domain/DDS 터미널에서
`ros2 run pinky_soccer_viz game_camera_view`를 실행합니다. 모니터는 읽기 전용이며
검출 알고리즘을 따로 실행하거나 주행 명령을 발행하지 않습니다.
원본 패널은 검출 노드가 이미 받은 입력의 `/ball_detection/source_image` 복사본을
사용합니다(검출 노드가 받은 `camera/image_raw` 메시지를 가공 없이 그대로 다시 보낸 것이라
원본 영상입니다. 네임스페이스가 있으면 `/<로봇>/ball_detection/source_image`). PC 모니터 때문에 로봇 원본 토픽의 원격 구독을 하나 더 만들지 않습니다.
인식·월드 모델·BT·제어를 따로 실행할 필요가 없습니다. 시작 전에는 정지 대기합니다.
한 번에 한 환경만 실행하고 기존 판단/제어/시뮬레이터는 해당 터미널에서 종료합니다.

| mode | 센서/물리 실행 | PC 경기 프로그램 | 시간 | RViz |
|---|---|---|---|---|
| real | 로봇의 robot.launch.py 유지 | game.launch.py mode:=real | 시스템 시간 | 자동 |
| gazebo | 경기 프로그램에서 Gazebo 자동 실행 | game.launch.py mode:=gazebo | /clock | 자동 |
| mujoco | 경기 프로그램에서 MuJoCo 자동 실행 | game.launch.py mode:=mujoco | /clock | 자동 |

행동을 하나씩 실행·평가하려면 `verify:=true`를 붙입니다(경기 트리 대신 검증 창에서 고른 행동만
실행). 자세한 내용은 [VERIFY.md](VERIFY.md).

경기장 기본값은 `field:=hardboard`, 원래 경기장은 `field:=rcj`입니다.
이동 제어는 기본 NMPC(`controller:=mpc`, 이전 비례 제어는 `controller:=reactive`)입니다.
속도 상한 기본(`auto`): 실물 전진0.08m/s·회전0.5rad/s, 시뮬레이션은 바퀴 한계(모터 사양 90 %,
약0.27m/s)와 회전2rad/s(더 빠르면 위치 추정이 깨짐). `max_lin`, `max_ang`로 변경합니다.
기본 우리 골대는 노랑, +X 파란 골대 방향으로 공격합니다.

위치 추정 기본은 `localization:=lidar`입니다. 경기장 YAML로 만든 LiDAR 지도와
AMCL을 사용하며, 골대 색/지자기 방향 기준으로180° 대칭 후보를 확인합니다.
기록/센서 상태/실물 보정은 [LOCALIZATION.md](../pinky_soccer_world_model/LOCALIZATION.md).
기존 바퀴 누적 방식만 시험하려면 `localization:=odom_only`를 지정합니다.

## 처음 한 번 PC 빌드

```bash
cd ~/pinky-soccer
source /opt/ros/jazzy/setup.bash
colcon build --symlink-install --packages-select pinky_soccer_bringup pinky_soccer_sim pinky_soccer_world_model pinky_soccer_viz
```

이미 빌드된 나머지 의존 패키지가 설치되어 있다는 전제입니다.

## 실물

로봇에서 센서/모터 드라이버를 한 번 실행합니다. 이미 실행 중이면 유지합니다.
공식·wrapper 워크스페이스를 source한 로봇 터미널에서:

```bash
ros2 launch pinky_soccer_bringup robot.launch.py imu_enabled:=true adc_enabled:=true
```

PC의 **경기 실행/시작 신호 터미널 둘 다** 다음 환경을 사용합니다.
domain 37과 XML의 로봇 IP/네트워크 인터페이스는 실제 로봇 설정과 맞아야 합니다.

```bash
source ~/pinky-soccer/install/setup.bash
export ROS_DOMAIN_ID=37
export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
export CYCLONEDDS_URI=file://$HOME/cyclonedds.xml
```

로봇을 경기장 중앙에서 파란 골대를 향하게 놓고 PC 터미널 A에서:

```bash
ros2 launch pinky_soccer_viz game.launch.py mode:=real field:=hardboard allow_uncalibrated:=true
```

RViz와 공 인식 영상 창이 열립니다. AMCL이 시작 위치 주변에서 LiDAR 지도를 정합합니다.
미보정 옵션은 실제 측정값 대신 HFOV66°·중앙 주점·왜곡0·실행 URDF 장착 자세를
가정한 시험 모드이며 영상에 APPROXIMATE를 표시합니다. 정확한 보정 후에는
`allow_uncalibrated`를 빼고 실행합니다. 자세한 옵션은 [REAL_GAME.md](REAL_GAME.md).

## Gazebo

로봇과 분리된 domain118을 사용합니다. PC의 **두 터미널 모두**:

```bash
source ~/pinky-soccer/install/setup.bash
export ROS_DOMAIN_ID=118
export RMW_IMPLEMENTATION=rmw_cyclonedds_cpp
unset CYCLONEDDS_URI
```

`unset`은 이 터미널에서만 로봇 전용 DDS XML 사용을 해제합니다.
실물의 XML/설정 파일은 변경하지 않습니다.

터미널 A:

```bash
ros2 launch pinky_soccer_viz game.launch.py mode:=gazebo field:=hardboard
```

Gazebo·RViz·인식·판단·제어가 함께 실행됩니다.

## MuJoCo

Gazebo와 같은 PC 환경(domain118·CYCLONEDDS_URI 해제)을 두 터미널에 사용합니다.
Gazebo를 먼저 종료한 다음 터미널 A:

```bash
ros2 launch pinky_soccer_viz game.launch.py mode:=mujoco field:=hardboard
```

MuJoCo 뷰어·RViz·인식·판단·제어가 함께 실행됩니다.
시뮬레이션 두 종류 모두 IMU/ADC 어댑터는 기본 활성화합니다.
IR raw ADC는 실측 보정표가 없으면 생성하지 않는 기존 규칙을 유지합니다.

## 공통 시작·정지

터미널 B에서 **환경을 해당 경기와 동일하게 설정한 뒤**:

```bash
# 시작: 로봇/시뮬레이션이 자동으로 탐색·판단·주행
ros2 topic pub --once /game/playing std_msgs/msg/Bool '{data: true}'

# 정지
ros2 topic pub --once /game/playing std_msgs/msg/Bool '{data: false}'
```

종료는 정지 신호를 보낸 뒤 터미널 A의 Ctrl+C입니다.
모드 전환 시 기존 프로그램을 종료합니다. 새 launch는 매번 정지 대기부터 시작합니다.

### 시작 명령이 구독자를 기다릴 때

`Waiting for at least 1 matching subscription(s)...`는 `/game/playing` 구독자를
발견하지 못했다는 뜻입니다. Gazebo 창만 실행한 경우 전체 경기 launch가 필요합니다.
전체 경기 launch가 실행 중이라면 신호 터미널의 ROS domain/DDS 설정을 맞춥니다.
2026-11-21 실제 진단에서는 domain118의 `world_model_node` 구독자와 월드 모델 수신이
정상이었으므로, 다음처럼 신호 명령에 환경을 직접 지정할 수 있습니다.

```bash
# 시뮬레이션 domain118에 시작 신호 (실물용 DDS XML은 이 명령에서만 해제)
env -u CYCLONEDDS_URI ROS_DOMAIN_ID=118 RMW_IMPLEMENTATION=rmw_cyclonedds_cpp \
  ros2 topic pub --once /game/playing std_msgs/msg/Bool '{data: true}'

# 같은 환경으로 정지
env -u CYCLONEDDS_URI ROS_DOMAIN_ID=118 RMW_IMPLEMENTATION=rmw_cyclonedds_cpp \
  ros2 topic pub --once /game/playing std_msgs/msg/Bool '{data: false}'
```

118은 연결을 보장하는 특별한 값이 아니라 두 프로세스가 같게 사용해야 하는 domain 번호입니다.

## 로봇 이름·소속·2대 경기 (2026-11-24)

### 로봇 이름과 소속

| 옵션 | 뜻 |
|---|---|
| `robot_name:=<이름>` | 그 로봇의 모든 토픽을 `/<이름>/...`으로, TF는 `/<이름>/tf`로 분리. 비우면 예전처럼 이름 없음 |
| `team:=Y` / `team:=B` | 소속. Y = 노랑 골대를 지킴(−X 수비, +X 공격), B = 파랑 골대를 지킴. 비우면 `our_goal_color` |

실물 2대는 로봇과 PC 양쪽에 같은 이름을 줍니다.

```bash
# 로봇 1 (로봇에서)            # PC
ros2 launch pinky_soccer_bringup robot.launch.py robot_name:=yellow
ros2 launch pinky_soccer_viz game.launch.py mode:=real robot_name:=yellow team:=Y
# 로봇 2
ros2 launch pinky_soccer_bringup robot.launch.py robot_name:=blue
ros2 launch pinky_soccer_viz game.launch.py mode:=real robot_name:=blue team:=B referee:=false
```

심판(골 판정)은 한 경기에 하나만 실행합니다(두 번째 PC는 `referee:=false`).
실물 심판은 시뮬레이션의 정답 위치가 없으므로 그 로봇 월드 모델의 공 추정(분실 아님, 2σ 안쪽까지
골라인을 넘음, 3회 연속)으로 판정합니다. 공이 카메라에 안 보이면 골을 놓칠 수 있습니다.

### 시뮬레이션 1대·2대

```bash
ros2 launch pinky_soccer_viz game.launch.py mode:=mujoco robots:=2                 # 상대도 경기
ros2 launch pinky_soccer_viz game.launch.py mode:=gazebo robots:=2 team:=B
ros2 launch pinky_soccer_viz game.launch.py mode:=mujoco robots:=2 opponent_mode:=lateral \
    opponent_speed:=0.15 opponent_travel:=0.5                                      # 장애물
```

| 옵션 | 기본 | 뜻 |
|---|---|---|
| `robots` | `1` | `2`면 상대 로봇 추가 |
| `robot_name` / `opponent_name` | 1대: 없음, 2대: `yellow`/`blue`(소속 색) | 네임스페이스 |
| `opponent_mode` | `game` | `game` 상대도 전체 판단으로 경기, `static` 가만히, `lateral` 옆으로 놓여 좌우 왕복, `longitudinal` 우리 쪽을 보고 앞뒤 왕복 |
| `opponent_speed` | `0.10` | 왕복 속도 [m/s] |
| `opponent_travel` | `0.40` | 왕복 거리 [m] |
| `opponent_x/y/yaw` | `auto` | game: 상대 진영 킥오프 자리, 장애물: 우리 공격 진영 x = ±0.4 |
| `initial_x/y/yaw` | `auto` | 우리 시작 = 킥오프 자리(자기 진영, 중앙에서 0.4 m 뒤, 상대 골대 방향) |

장애물 모드의 상대는 판단 없이 `obstacle_driver`만 돌며 `/game/playing`과 무관하게 바로 움직입니다
(이동 검증용 장애물). 시뮬에서는 정답 위치로 출발선을 유지하므로 왕복 거리·방향이 일정합니다
(MuJoCo 측정: 좌우 0.525 m/설정 0.5, 방향 90° 유지, 0.143 m/s/설정 0.15).
시뮬 기본 공 위치는 1대·2대 모두 센터 스팟입니다(2026-11-24부터).

### 골과 킥오프

공 전체가 골라인을 넘으면(공 중심이 라인 + 반지름 0.021 m 너머, 골포스트 사이) `game_referee`가:
1. `/game/goal`(JSON: 들어간 골대·득점 팀·점수), `/game/score` 발행
2. `/game/playing` = false → 모든 로봇 경기 정지
3. `/game/kickoff` = true → 모든 로봇이 자기 킥오프 자리(시작 자세)로 이동해 대기
4. 시뮬레이션: 1초 뒤 공을 센터 스팟에 정지 상태로 순간이동
5. 다음 시작 신호(`/game/playing` true)에서 kickoff 해제, 경기 재개

```bash
ros2 topic echo /game/score        # 점수
```

### 여러 로봇일 때 DDS 참가자 수

ROS 프로세스 하나가 DDS 참가자 하나입니다. 2대 전체 스택(+시뮬레이터)은 약 45개라 CycloneDDS의 기본
참가자 번호 한도를 넘어 `Failed to find a free participant index`로 노드가 뜨지 못했습니다.
경기 launch는 실행하는 프로세스에 한도를 120으로 올려 줍니다(사용자 XML은 그대로 두고 덧붙임).
**신호를 보내는 터미널에도 같은 설정이 필요합니다.**

```bash
export CYCLONEDDS_URI="${CYCLONEDDS_URI:+$CYCLONEDDS_URI,}<CycloneDDS><Domain id=\"any\"><Discovery><MaxAutoParticipantIndex>120</MaxAutoParticipantIndex></Discovery></Domain></CycloneDDS>"
ros2 topic pub --once /game/playing std_msgs/msg/Bool '{data: true}'
```

## RViz 경기장 모니터

`soccer.rviz`를 자동 로드하고 Fixed Frame은 `map`입니다.
선택한 YAML의 경기장/골대, 추정 로봇/공/상대 위치, 공 불확실성·예측 궤적,
탐색 히트맵 및 행동 목표를 표시합니다. 자기 위치는 실물의 경우 odom 기반입니다.
히트맵은 `/world_model/search_grid_markers` 색상 마커로 표시해 이 PC에서 확인된
RViz Map의 indexed texture 셰이더 오류를 피합니다. 원본 OccupancyGrid도 계속 제공합니다.
경기 상태 모니터의 자기 위치는 기본 LiDAR AMCL 보정 TF를 따릅니다.
골대 색/지자기 방향 기준 상태는 `/localization/status`에서 확인합니다.
모든 GUI를 끄려면 `headless:=true`를 추가합니다.

실물에서 거리 정확도·게임 성공은 보정 및 현장 검증이 필요합니다.
시뮬레이션에서는 근거리 사각·odom 드리프트로 경기 성공이 제한될 수 있습니다.
